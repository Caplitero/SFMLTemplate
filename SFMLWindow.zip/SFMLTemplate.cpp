


#include "GameClass.h"


int main()
{
   
    SFMLWindow window(sf::VideoMode(600, 600), "SFML");
    window.Start();
   
    return 0;
}

